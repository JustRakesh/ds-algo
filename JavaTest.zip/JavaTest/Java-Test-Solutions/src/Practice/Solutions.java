package Practice;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class Solutions {

	public static void main(String[] args) {
		List<Integer>  list1=new ArrayList<Integer>();
		List<Integer>  list2=new ArrayList<Integer>();
		list1.add(1);
		list1.add(2);
		list1.add(3);
		list1.add(4);
		list2.add(5);
		list2.add(6);
		list2.add(7);
		list2.add(8);
		list1.stream().forEach(c -> list2.stream().forEach(d -> {if((c+d)%3==0) System.out.println(c+" "+d);}));
		String input="How many eggs do  u have    13?";
	}
	public int numberOfWords(String input) {
		int count =0;
		return count;
	}
	
}

