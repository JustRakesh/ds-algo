package boku;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;


public class CoinChange {
    static List<Integer> getFewestCoinsForAmount(List<Integer> coins, int amount) {
        Collections.sort(coins);
        List<Integer> result=new ArrayList();
        int index=coins.size()-1;
        while(amount > 0){
            int coinValue=coins.get(index);
            index--;
            int coinsCount=amount/coinValue;
            while(coinsCount > 0){
                result.add(coinValue);
                coinsCount--;
            }
            int change=amount%coinValue;
            amount=change;
        }
        return result;
    }



    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter wr = new PrintWriter(System.out);

        String input = bufferedReader.readLine().trim().replaceAll("\\[|\\]", "");
        
        List<String> coinsStringList = new ArrayList<String>(Arrays.asList(input.split(", |,")));
        
        // Coin denominations
        List<Integer> coins = coinsStringList.stream() 
            .map(Integer::parseInt) 
            .collect(Collectors.toList()); 
        
        // Target amount
        int amount = coins.remove(coins.size()-1);

        List<Integer> result = CoinChange.getFewestCoinsForAmount(coins, amount);

        System.out.println(String.valueOf(result));

        wr.close();
        bufferedReader.close();
    }
}