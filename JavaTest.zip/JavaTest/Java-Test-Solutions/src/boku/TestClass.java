package boku;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

public class TestClass {
	private static int[][] adjacencyMatrix;

	public TestClass(int[][] input) {
		adjacencyMatrix = input;
	}

	static int numPaths(int sourceNode, int destNode, int maxSteps) {
		int count = 0;
		while (maxSteps > 0) {
			for (int i = 0; i < adjacencyMatrix.length; i++) {
				if (adjacencyMatrix[sourceNode][i] == 1)
					count += numPaths(i, destNode, maxSteps - 1);

			}
		}
		return count;
	}

	public static void main(String[] args) throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		PrintWriter wr = new PrintWriter(System.out);

		int vertices = Integer.parseInt(bufferedReader.readLine().trim());
		int[][] graphMatrix = new int[vertices][vertices];
		for (int i = 0; i < vertices; i++) {
			String[] row = bufferedReader.readLine().trim().split(" ");
			for (int j = 0; j < vertices; j++) {
				graphMatrix[i][j] = Integer.parseInt(row[j]);
			}
		}
		List<String> functionInputRowString = new ArrayList<String>(
				Arrays.asList(bufferedReader.readLine().trim().split(" ")));
		List<Integer> functionInputRow = functionInputRowString.stream().map(Integer::parseInt)
				.collect(Collectors.toList());

		TestClass graph = new TestClass(graphMatrix);
		int result = TestClass.numPaths(functionInputRow.get(0), functionInputRow.get(1), functionInputRow.get(2));

		System.out.println(result);

		wr.close();
		bufferedReader.close();
	}

}
