package druva;

public class Solution {

	/*
	 * Given an n x n matrix, every row and column is sorted in increasing order.
	 * Search a given number in matrix.
	 * 
	 * [[10, 20, 30, 40], [15, 25, 35, 45], [27, 29, 37, 48], [32, 33, 39, 50]]
	 * 
	 * Find: 37
	 */

	public static boolean findNumber(int[][] input, int number) {
		for (int i = 0; i < input.length; i++) {

			boolean value = search(input[i], 0, input[i].length - 1, number);
			if (value)
				return true;
		}
		return false;
	}

	public static boolean search(int[] input, int left, int right, int num) {
		if (right < left)
			return false;
		int mid = left + (right - left) / 2;
		if (input[mid] == num)
			return true;
		else if (num > input[mid]) {
			return search(input, mid + 1, right, num);
		} else {
			return search(input, left, mid - 1, num);
		}
	}

	public static void main(String[] args) {
		int[][] input = new int[][] { { 10, 20, 30, 40 }, { 15, 25, 35, 45 }, { 27, 29, 37, 48 }, { 32, 33, 39, 50 } };
		boolean result = findNumber(input, 99);
		System.out.println(result);
	}
}
