package ea;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Solutions {

	public static void main(String[] args) {
		String input = "India is my country and all Indians are my brothers and sisters";
		getmaxFrequency(input);
	}

	public static void getmaxFrequency(String input) {
		int maxFrequency = 0;
		Map<String, Integer> map = new HashMap<String, Integer>();
		String[] strArray = input.split(" ");
		System.out.println(strArray);
		for (int i = 0; i < strArray.length; i++) {
			String key = strArray[i];
			Integer value = map.get(key);
			if (value == null) {
				map.put(key, 1);

			} else {
				map.put(key, ++value);
			}

		}
		System.out.println(map);
		System.out.println(map.entrySet().stream().max(Map.Entry.comparingByValue()).get());
	}
}
