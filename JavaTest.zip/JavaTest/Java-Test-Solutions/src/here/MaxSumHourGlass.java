package here;

public class MaxSumHourGlass {

	public static void main(String[] args) {
		int[][] input = new int[][] { { 1, 2, 3, 4 }, { 0, 1, 3, 4 }, { 1, 4, 6, 2 }, { 1, 1, 2, 2 } };
		int sum = findMaxSumHourGlassMatrix(input);
		System.out.println(sum);
	}

	public static int findMaxSumHourGlassMatrix(int[][] input) {
		int result = Integer.MIN_VALUE;
		for (int i = 0; i < input.length - 2; i++) {
			for (int j = 0; j < input[i].length - 2; j++) {
				int sum = input[i][j] + input[i][j + 1] + input[i][j + 2] + input[i + 1][j + 1] + input[i + 2][j]
						+ input[i + 2][j + 1] + input[i + 2][j + 2];
				if (sum > result)
					result = sum;
			}
		}
		return result;
	}
}
