package here;

import java.util.HashMap;
import java.util.Map;

public class NonRepeatingChar {

	public static char findFirstNonRepeatingChar(String input) {
		Map<Character,Integer> map= new HashMap();
		char[] charArray= input.toCharArray();
		for(int i=0 ; i< charArray.length; i++) {
			char ch= charArray[i];
			Integer value= map.get(ch);
			if(value == null)
				map.put(ch, 1);
			else {
				map.put(ch,  ++value);
			}
		}
		for(int j=0 ; j<charArray.length; j++) {
			int count=map.get(charArray[j]);
			if(count==1)
				return charArray[j];
		}
		return '\u0000';
	}
	public static void main(String[] args) {
	
		char ch=findFirstNonRepeatingChar("hello");
		System.out.println(ch);
	}
}
