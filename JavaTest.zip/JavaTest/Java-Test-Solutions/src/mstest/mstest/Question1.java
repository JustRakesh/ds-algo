package mstest;

public class Question1 {

	public static void main(String[] args) {
		try {
			throw new Exc1();
		} catch (Exc0 ex) {
			System.out.println("Exc0 caight");
		} catch (Exception ex) {
			System.out.println("Exception Caught");
		}
	}
}

class Exc0 extends Exception {
}

class Exc1 extends Exc0 {
}