package mstest;

public abstract class Question3 {

	public int getNum() {
		return 45;
	}
	public abstract class Bar {

		public int getNum() {
			return 38;
		}
		
	}
	public static void main(String[] args) {
		Question3 q3 = new Question3() {
			public int getNum() {
				return 22;
			}
		};
		Question3.Bar bar = q3.new Bar() {
			public int getNum() {
				return 57;
			}
		};
		System.out.println(q3.getNum() +" "+bar.getNum());
	}
}
