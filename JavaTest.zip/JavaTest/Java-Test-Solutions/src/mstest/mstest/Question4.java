package mstest;

public class Question4 {

	public static void main(String[] args) {
		 new Mythread().start();
		 new Mythread(new MyRunnable()).start();
		
	}
}
class Mythread extends Thread{
	Mythread(){}
	Mythread(Runnable r){super(r);}
	public void run() {
		System.out.println("Inside Thread");
	}
}
class MyRunnable implements Runnable{
	
	public void run() {
		System.out.println("Inside Runnable");
	}
}
