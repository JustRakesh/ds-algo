package mstest;

import java.util.HashSet;

public class Question6 {

	 private String s;
	 Question6(String str){
		 this.s=str;
	 }
	 public static void main(String[] args) {
		HashSet<Object> hs = new HashSet<Object>();
		Question6 s1= new Question6("abc");
		Question6 s2= new Question6("abc");
		String str1= new String("abc");
		String str2= new String("abc");
		hs.add(s1);
		hs.add(s2);
		hs.add(str1);
		hs.add(str2);
		System.out.println(hs.size());

	}
}
