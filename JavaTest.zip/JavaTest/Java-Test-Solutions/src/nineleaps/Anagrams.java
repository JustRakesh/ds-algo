package nineleaps;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Anagrams {

	public static boolean isAnagram(String input1, String input2) {

		char[] inputCharArray1 = input1.toCharArray();
		char[] inputCharArray2 = input2.toCharArray();
		if (inputCharArray1.length != inputCharArray2.length)
			return false;
		int[] charArray = new int[26];
		for (int i = 0; i < inputCharArray1.length; i++) {
			int index = inputCharArray1[i] - 'a';
			charArray[index] += 1;
		}
		for (int i = 0; i < inputCharArray2.length; i++) {
			int index = inputCharArray2[i] - 'a';
			charArray[index] -= 1;
		}
		for (int i = 0; i < charArray.length; i++) {
			if (charArray[i] != 0)
				return false;
		}
		return true;
	}

	public static List<Integer> findDifferenceOfCharacterInAnagrams(List<String> input1, List<String> input2,
			int length) {
		List<Integer> result = new ArrayList<Integer>();
		for (int i = 0; i < length; i++) {
			int[] charArray = new int[26];
			char[] str1 = input1.get(i).toCharArray();
			char[] str2 = input2.get(i).toCharArray();
			if (str1.length != str2.length)
				result.add(-1);
			else {
				int count = 0;
				for (int j = 0; j < str1.length; j++) {
					int index = str1[j] - 'a';
					charArray[index] = charArray[index] + 1;
				}
				for (int k = 0; k < str2.length; k++) {
					int index = str2[k] - 'a';
					charArray[index] = charArray[index] - 1;
				}
				for (int z = 0; z < charArray.length; z++) {
					if (charArray[z] != 0) {
						count = count + Math.abs(charArray[z]);
					}
				}
				result.add(count / 2);
			}

		}
		return result;
	}

	public static void main(String[] args) {
		List<String> input1 = Arrays.asList(new String[] { "abcd", "bgty", "qwerty", "asdf", "asdf" });
		List<String> input2 = Arrays.asList(new String[] { "badc", "bgth", "qwer", "asdd", "zxcv" });
		List<String> inputStream1 = Stream.of("abcd", "bgty", "qwerty", "asdf", "asdf").collect(Collectors.toList());
		List<String> inputStream2 = Stream.of("badc", "bgth", "qwer", "asdd", "zxcv").collect(Collectors.toList());
		System.out.println(Anagrams.findDifferenceOfCharacterInAnagrams(input1, input2, 5));
		System.out.println(Anagrams.findDifferenceOfCharacterInAnagrams(inputStream1, inputStream2, 5));
		System.out.println(Anagrams.isAnagram("abbc", "acbe"));
	}
}
