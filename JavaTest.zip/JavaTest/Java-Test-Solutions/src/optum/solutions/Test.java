package optum.solutions;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Test {
	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<>();
		Integer value = map.get("");
		System.out.println(value);
		for (Entry<String, Integer> entry : map.entrySet()) {

		}
	}
}