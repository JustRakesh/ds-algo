package oracle;

import java.util.Comparator;
import java.util.Map;

public class SortComparator implements Comparator<Integer> {

	private final Map<Integer, Integer> freqMap;

	public SortComparator(Map<Integer, Integer> freqMap) {
		this.freqMap = freqMap;
	}

	@Override
	public int compare(Integer k1, Integer k2) {

		int freqCompare = freqMap.get(k2).compareTo(freqMap.get(k1));
		int valueCompare = k1.compareTo(k2);
		if (freqCompare == 0)
			return valueCompare;
		else
			return freqCompare;
	}

}
