package oracle;

import java.util.*;
import java.util.Map.Entry;

public class SortNumbersOfListByFrequency {
	public static void main(String[] args) {
		List<Integer> input = Arrays.asList(5, 6, 5, 6, 3, 5, 2);
		List<Integer> result = SortNumbersOfListByFrequency.sortOnFrequency(input);
		System.out.print(result);
	}

	public static List<Integer> sortOnFrequency(List<Integer> input) {
		List<Integer> result = new ArrayList<Integer>();
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (Integer current:input) {
			int count = map.getOrDefault(current, 0);
			map.put(current, count + 1);
			result.add(current);
		}
		Collections.sort(result, new SortComparator(map));
		return result;
	}
}
