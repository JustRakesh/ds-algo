package paypal;

import java.io.*;
import java.util.*;


public class TestClass {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter wr = new PrintWriter(System.out);
        
        int T = Integer.parseInt(br.readLine().trim());
        for(int t_i=0; t_i<T; t_i++)
        {
            String[] str= br.readLine().split(" ");
            
            int L = Integer.parseInt(str[0]);
            int R = Integer.parseInt(str[1]);

            int out_ = solve(L, R);
            System.out.println(out_);
         }

         wr.close();
         br.close();
    }
    static int solve(int L, int R){
        int count=0;
        List<Integer> primes=new ArrayList<>();
        int j=1;
        for(int i=L; i<=R;i++){
            if(isPrime(i)){
                primes.add(i);
            }
        }
        int nextPrime=R+1;
        while(!isPrime(nextPrime)){
            nextPrime++;
        }
        int previousprime=L-1;
        while(!isPrime(previousprime)){
            previousprime--;
        }
        
        for(int i=0 ; i<primes.size();i++){
            
            if(i==0){
                int mean=(previousprime + primes.get(i+1))/2;
                if(i > mean)
                ++count;
            }else if(i == primes.size()-1){
                int mean=(primes.get(i-1) + nextPrime)/2;
                if(i > mean)
                ++count;
            }else{
                int mean=(primes.get(i-1) + primes.get(i+1))/2;
                if(i > mean)
                ++count; 
            }

        }
        return count;
        }

    static boolean isPrime(int n){
        if(n<=1)
        return false;
        if(n<=3)
        return true;
        if(n%2 ==0 || n%3 ==0)
        return false;
        for(int i=5 ; i*i <=n;i=i+6){
            if(n % i==0 || n %(i+2)==0)
            return false;
        }
        return true;

    }    
}
