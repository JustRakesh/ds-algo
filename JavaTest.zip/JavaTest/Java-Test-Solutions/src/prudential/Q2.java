package prudential;

public class Q2 {
public static void main(String[] args) {
	B b = new B();
	boolean b1=b instanceof B;
	boolean b2=(b instanceof B) && (!(b instanceof A));
	boolean b3=b instanceof B && (!(b instanceof C));
	System.out.println(b1+" "+b2+" "+b3);
	
}
	
}
class A{}
class B extends A{}
class C extends B{}
