package prudential;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ScatterPalindrome {

	public static List<Integer> scatterPalindrome(List<String> strToEvaluate) {
		List<Integer> results = new ArrayList<Integer>();
		for (String str : strToEvaluate) {
			char[] charArray = str.toCharArray();
			int n = charArray.length;
			int result = countScatterPalindrome(charArray, n);
			results.add(result);

		}
		return results;
	}

	public static int countScatterPalindrome(char[] charArray, int n) {
		int dp[][] = new int[n][n];
		boolean P[][] = new boolean[n][n];
		for (int i = 0; i < n; i++) {
			P[i][i] = true;
		}
			
		for (int i = 0; i < n - 1; i++) {
			if (charArray[i] == charArray[i + 1]) {
				P[i][i + 1] = true;
				dp[i][i + 1] = 1;
			}
		}
		for (int gap = 2; gap < n; gap++) {
			for (int i = 0; i < n - gap; i++) {
				int j = gap + i;
				String str = String.copyValueOf(charArray, 0, j+1);
				boolean isScatterPalindrome=canFormPalindrome(str);
				if (isScatterPalindrome && P[i + 1][j - 1])
					P[i][j] = true;

				if (P[i][j] == true)
					dp[i][j] = dp[i][j - 1] + dp[i + 1][j] + 1 - dp[i + 1][j - 1];
				else
					dp[i][j] = dp[i][j - 1] + dp[i + 1][j] - dp[i + 1][j - 1];
			}
		}
		return dp[0][n - 1];

	}

	public static boolean canFormPalindrome(String str) {
		int count[] = new int[256];
		Arrays.fill(count, 0);
		for (int i = 0; i < str.length(); i++)
			count[(int) (str.charAt(i))]++;
		int odd = 0;
		for (int i = 0; i < 256; i++) {
			if ((count[i] & 1) == 1)
				odd++;

			if (odd > 1)
				return false;
		}
		return true;
	}

	public static void main(String[] args) {
		List<String> inputList = new ArrayList<String>();
		inputList.add("aeaea");
		List<Integer> result = scatterPalindrome(inputList);
		System.out.println(result);
	}
}
