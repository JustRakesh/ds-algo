package prudential;

import java.util.ArrayList;
import java.util.List;

public class Triplets {
	public static void main(String[] args) {
		List<Integer> list= new ArrayList<Integer>();
		list.add(3);
		list.add(1);
		list.add(2);
		list.add(4);
		long t=7;
		long result=triplets(t, list);
		System.out.println(result);
	}
	static long triplets(long t, List<Integer> d) {
		long result = 0;
		for (int i = 0; i < d.size() - 2; i++) {
			for (int j = i + 1; j < d.size() - 1; j++) {
				for (int k = j + 1; k < d.size(); k++) {
					int first = d.get(i);
					int second = d.get(j);
					int third = d.get(k);
					if ( first + second + third <= t) {
						++result;
					}
				}
			}

		}
		return result;
	}
}
