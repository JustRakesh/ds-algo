package stephen;

import java.io.*;
import java.util.*;

public class Test {
	static int minParkingSpaces(int[][] parkingStartEndTimes) {
		  sortbyColumn(parkingStartEndTimes);
		  int result=1;
          for(int i=0; i< parkingStartEndTimes.length; i++){
			  int slotsRequired=1;
			  for(int j=i+1; j<parkingStartEndTimes.length;j++){
				  if(parkingStartEndTimes[i][1] > parkingStartEndTimes[j][0]){
				  slotsRequired=slotsRequired+1;
			  	}
			}
			if(result < slotsRequired)
				result=slotsRequired;
		  }
		  
			return result;
	}
	public static void sortbyColumn(int arr[][]) 
    { 
        Arrays.sort(arr, new Comparator<int[]>() { 
            
          @Override              
          public int compare(final int[] entry1,  
                             final int[] entry2) {  
            if (entry1[0] > entry2[0]) 
                return 1; 
            else
                return -1; 
          } 
        }); 
    } 

	// DO NOT MODIFY ANYTHING BELOW THIS LINE!!

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		PrintWriter wr = new PrintWriter(System.out);
		int n = Integer.parseInt(br.readLine().trim());
		int[][] parkingStartEndTimeList = new int[n][2];
		String[] parkingStartEndTimes = br.readLine().split(" ");
		for (int i = 0; i < n; i++) {
			String[] parkingStartEndTime = parkingStartEndTimes[i].split(",");
			for (int j = 0; j < parkingStartEndTime.length; j++) {
				parkingStartEndTimeList[i][j] = Integer.parseInt(parkingStartEndTime[j]);
			}
		}

		int out = minParkingSpaces(parkingStartEndTimeList);
		System.out.println(out);

		wr.close();
		br.close();
	}
}
