package test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Solution {
	// Given a non-empty array of integers, return the third maximum number in this
	// array

	public static int findThirdMaxNumberBySorting(int[] input) {
		if (input != null && input.length >= 3) {
			Arrays.sort(input);
			int length=input.length-3;
			return input[length];
		} else {
			return -1;
		}

	}

	public static int findThirdMaxNumber(int[] input) {
		Set<Integer> set= new TreeSet<Integer>(); 
		for(int i=0; i<input.length; i++) {
			set.add(input[i]);
		}
		Iterator<Integer> itr=set.iterator();
		int count=0;
		int result=0;
		while(itr.hasNext()) {
			if(count==2) {
				result=itr.next();
			}else {
				itr.next();
				count++;
			}
		}
		return result;
	}

	public static void main(String[] args) {
		int[] input = new int[] { 11, 1, 2, 4, 13, 14 ,13,11};
		System.out.println(Solution.findThirdMaxNumber(input));

	}
}
