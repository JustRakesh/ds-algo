package com.ummo.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ummo.booking.entity.Booking;
import com.ummo.booking.entity.Driver;
import com.ummo.booking.service.Implementation.BookingService;

@RestController
public class BookingController {

	@Autowired
	private BookingService service;
	@PostMapping(path = "/create")
	public Driver create(Booking booking) {
		Driver driver= service.create(booking);
		return driver;
	}

	@GetMapping(path = "/search")
	public Booking search(@RequestParam long orderno) {
		return service.search(orderno);
	}

	@GetMapping(path = "/findAllBookings")
	public List<Booking> findAllBookings() {
		return service.findAllBookings();
	}
	@GetMapping(path = "/findBookingsByCustomerName")
	public List<Booking> findBookingsByCustomerName(@RequestParam String customerName) {
		return service.findBookingsByCustomerName(customerName);
	}
}
