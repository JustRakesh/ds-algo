package com.ummo.booking.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ummo.booking.entity.Driver;
import com.ummo.booking.service.Interface.IDriverService;

@RestController
public class DriverController {
	@Autowired
	private IDriverService service;

	@GetMapping(path = "/bulkcreate")
	public String bulkCreate() {
		List<Driver> drivers = new ArrayList<Driver>();
		Driver d1 = new Driver("Rakesh", 40.096, -140.096, true);
		Driver d2 = new Driver("Pawan", 50.096, -150.096, true);
		Driver d3 = new Driver("Stephen", 60.096, -160.096, true);
		drivers.add(d1);
		drivers.add(d2);
		drivers.add(d3);
		return service.bulkCreate(drivers);
	}

	@PostMapping(path = "/create")
	public String create(Driver driver) {
		return service.create(driver);
	}

	@GetMapping(path = "/search")
	public Driver search(@RequestParam long id) {
		return service.search(id);
	}

	@GetMapping(path = "/findAllDrivers")
	public List<Driver> findAllDrivers() {
		return service.findAllDriver();
	}

	@GetMapping(path = "/findDriverByStatus")
	public List<Driver> findDriverByStatus(@RequestParam boolean status) {
		return service.finDriverByStatus(status);
	}

}
