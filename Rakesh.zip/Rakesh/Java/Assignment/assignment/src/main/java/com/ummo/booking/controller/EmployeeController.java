package com.ummo.booking.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ummo.booking.entity.Employee;
import com.ummo.booking.service.Implementation.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping(path = "/bulkcreate")
	public String bulkCreate() {
		List<Employee> employees = new ArrayList<Employee>();
		Employee emp1 = new Employee( "Rakesh", "Shaw", 10000);
		Employee emp2 = new Employee( "Pawan", "Soni", 10000);
		Employee emp3 = new Employee( "Stephen", "Fernandes", 10000);
		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
		return employeeService.bulkCreate(employees);
	}

	@PostMapping(path = "/create")
	public String create(@RequestBody Employee employee) {
		return employeeService.create(employee);
	}

	@GetMapping(path = "/findAll")
	public List<Employee> findAll() {
		return employeeService.findAllEmployees();
	}

	@GetMapping(path = "/search")
	public Employee search(@RequestParam long id) {
		return employeeService.search(id);
	}

	@GetMapping(path = "/searchbyfirstname")
	public List<Employee> searchbyfirstname(String firstName) {
		return employeeService.findEmployeesByFirstName(firstName);
	}
}
