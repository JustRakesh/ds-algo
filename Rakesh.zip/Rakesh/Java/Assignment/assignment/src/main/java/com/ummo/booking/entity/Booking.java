package com.ummo.booking.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "booking")
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ordernumber")
	private long orderNumber;
	@Column(name = "customername")
	private String customerName;
	@Column(name = "customerlatitude")
	private double customerLatitude;
	@Column(name = "customerlongitude")
	private double customerLongitude;

	public Booking() {
		super();
	}

	public Booking(String customerName, double customerLatitude, double customerLongitude) {
		super();
		this.customerName = customerName;
		this.customerLatitude = customerLatitude;
		this.customerLongitude = customerLongitude;
	}

	public long getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(long orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getCustomerLatitude() {
		return customerLatitude;
	}

	public void setCustomerLatitude(double customerLatitude) {
		this.customerLatitude = customerLatitude;
	}

	public double getCustomerLongitude() {
		return customerLongitude;
	}

	public void setCustomerLongitude(double customerLongitude) {
		this.customerLongitude = customerLongitude;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(customerLatitude);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(customerLongitude);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result + (int) (orderNumber ^ (orderNumber >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Booking other = (Booking) obj;
		if (Double.doubleToLongBits(customerLatitude) != Double.doubleToLongBits(other.customerLatitude))
			return false;
		if (Double.doubleToLongBits(customerLongitude) != Double.doubleToLongBits(other.customerLongitude))
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (orderNumber != other.orderNumber)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Booking [orderNumber=" + orderNumber + ", customerName=" + customerName + ", customerLatitude="
				+ customerLatitude + ", customerLongitude=" + customerLongitude + "]";
	}

}
