package com.ummo.booking.repository;

import org.springframework.stereotype.Repository;

import com.ummo.booking.entity.Employee;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	List<Employee> findByFirstName(String FirstName);
	List<Employee> findAll();
}
