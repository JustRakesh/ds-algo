package com.ummo.booking.service.Implementation;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ummo.booking.entity.Booking;
import com.ummo.booking.entity.Driver;
import com.ummo.booking.repository.BookingRepository;
import com.ummo.booking.service.Interface.IBookingService;

@Service
public class BookingService implements IBookingService {

	@Autowired
	private BookingRepository repository;

	@Override
	public Driver create(Booking booking) {
		booking=repository.save(booking);
		return new Driver();
	}

	@Override
	public Booking search(long ordernumber) {
		Optional<Booking> driver = repository.findById(ordernumber);
		return driver.get();
	}

	@Override
	public List<Booking> findAllBookings() {
		List<Booking> drivers = repository.findAll();
		return drivers;
	}

	@Override
	public List<Booking> findBookingsByCustomerName(String customerName) {
		return repository.findByCustomerName(customerName);
	}

	public static double distance(double lat1, double lat2, double lon1, double lon2) {
		lon1 = Math.toRadians(lon1);
		lon2 = Math.toRadians(lon2);
		lat1 = Math.toRadians(lat1);
		lat2 = Math.toRadians(lat2);

		double dlon = lon2 - lon1;
		double dlat = lat2 - lat1;
		double a = Math.pow(Math.sin(dlat / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(dlon / 2), 2);
		double c = 2 * Math.asin(Math.sqrt(a));

		double r = 6371;
		return (c * r);
	}
}
