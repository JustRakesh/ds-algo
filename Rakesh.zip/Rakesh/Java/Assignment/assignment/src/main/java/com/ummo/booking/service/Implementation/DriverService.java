package com.ummo.booking.service.Implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ummo.booking.entity.Driver;
import com.ummo.booking.repository.DriverRepository;
import com.ummo.booking.service.Interface.IDriverService;

@Service
public class DriverService implements IDriverService {
	@Autowired
	private DriverRepository repository;

	@Override
	public String bulkCreate(List<Driver> drivers) {
		repository.saveAll(drivers);
		return "Drivers are created.";
	}

	@Override
	public String create(Driver driver) {
		repository.save(driver);
		return "Diver is created.";
	}

	@Override
	public Driver search(long id) {
		Optional<Driver> driver = repository.findById(id);
		return driver.get();
	}

	@Override
	public List<Driver> findAllDriver() {
		List<Driver> drivers = repository.findAll();
		return drivers;
	}

	@Override
	public List<Driver> finDriverByStatus(boolean status) {
		List<Driver> drivers = repository.findByStatus(status);
		return drivers;
	}

}
