package com.ummo.booking.service.Implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ummo.booking.entity.Employee;
import com.ummo.booking.repository.EmployeeRepository;
import com.ummo.booking.service.Interface.IEmployeeService;

@Service
public class EmployeeService implements IEmployeeService {
	@Autowired
	private EmployeeRepository repository;

	@Override
	public String bulkCreate(List<Employee> employees) {
		repository.saveAll(employees);
		return "Employees are created";
	}

	@Override
	public String create(Employee employee) {
		repository.save(employee);
		return "Employee is created";
	}

	@Override
	public Employee search(long id) {
		Optional<Employee> employee = repository.findById(id);
		return employee.get();
	}

	@Override
	public List<Employee> findAllEmployees() {
		List<Employee> employees = repository.findAll();
		return employees;
	}

	@Override
	public List<Employee> findEmployeesByFirstName(String firstName) {
		List<Employee> employees = repository.findByFirstName(firstName);
		return employees;
	}

}
