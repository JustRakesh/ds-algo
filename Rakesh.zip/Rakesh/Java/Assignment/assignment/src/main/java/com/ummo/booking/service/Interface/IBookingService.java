package com.ummo.booking.service.Interface;

import java.util.List;

import com.ummo.booking.entity.Booking;
import com.ummo.booking.entity.Driver;

public interface IBookingService {

	Driver create(Booking driver);

	Booking search(long ordernumber);

	List<Booking> findAllBookings();

	List<Booking> findBookingsByCustomerName(String customerName);

}
