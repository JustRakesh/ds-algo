package com.ummo.booking.service.Interface;

import java.util.List;

import com.ummo.booking.entity.Driver;;

public interface IDriverService {

	String bulkCreate(List<Driver> drivers);

	String create(Driver driver);

	Driver search(long id);

	List<Driver> findAllDriver();

	List<Driver> finDriverByStatus(boolean status);

}
