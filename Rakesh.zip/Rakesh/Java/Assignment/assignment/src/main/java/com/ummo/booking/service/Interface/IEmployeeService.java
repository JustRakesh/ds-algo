package com.ummo.booking.service.Interface;

import java.util.List;

import com.ummo.booking.entity.Employee;

public interface IEmployeeService {

	String bulkCreate(List<Employee> employees);

	String create(Employee employee);

	Employee search(long id);

	List<Employee> findAllEmployees();

	List<Employee> findEmployeesByFirstName(String firstName);
}
