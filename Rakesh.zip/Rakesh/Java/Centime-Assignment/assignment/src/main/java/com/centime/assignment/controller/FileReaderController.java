package com.centime.assignment.controller;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;

@RestController
public class FileReaderController {

	@PostMapping(path = "/upload")
	public String convertFileContentToJson(@RequestBody MultipartFile file) throws JsonProcessingException {
		JSONArray responseArray = new JSONArray();
		Workbook workbook = null;
		FileInputStream inputStream = null;
		try {

			inputStream = (FileInputStream) file.getInputStream();
			workbook = new XSSFWorkbook(inputStream);
			Sheet invSheet = workbook.getSheetAt(0);
			int rowNum = invSheet.getLastRowNum() + 1;
			int colNum = invSheet.getRow(0).getLastCellNum();
			Row row = null;
			Map<String, Integer> colMapByName = new HashMap<String, Integer>();
			if (invSheet.getRow(0).cellIterator().hasNext()) {
				for (int j = 0; j < colNum; j++) {
					colMapByName.put(invSheet.getRow(0).getCell(j).getStringCellValue(), j);
				}
			}
			for (int i = 1; i < rowNum; i++) {
				try {
					row = invSheet.getRow(i);
					long id = (long) row.getCell(colMapByName.get("Id")).getNumericCellValue();
					String itemNumber = row.getCell(colMapByName.get("ItemNumber")) != null
							? row.getCell(colMapByName.get("ItemNumber")).getStringCellValue()
							: null;
					String itemName = row.getCell(colMapByName.get("ItemName")) != null
							? row.getCell(colMapByName.get("ItemName")).getStringCellValue()
							: null;
					String itemName = row.getCell(colMapByName.get("ItemName")) != null
							? row.getCell(colMapByName.get("ItemName")).getStringCellValue()
							: null;
					String orgLOBCode = row.getCell(colMapByName.get("LOBCode")) != null
							? row.getCell(colMapByName.get("LOBCode")).getStringCellValue()
							: null;
					String orgLOBName = null;
					String baseOrgEntityCode = row.getCell(colMapByName.get("EntityCode")) != null
							? row.getCell(colMapByName.get("EntityCode")).getStringCellValue()
							: null;
					String baseOrgEntityName = row.getCell(colMapByName.get("EntityName")) != null
							? row.getCell(colMapByName.get("EntityName")).getStringCellValue()
							: null;
					String itemDescription = row.getCell(colMapByName.get("ItemDescription")) != null
							? row.getCell(colMapByName.get("ItemDescription")).getStringCellValue()
							: null;
					String itemSpecification = row.getCell(colMapByName.get("ItemSpecification")) != null
							? row.getCell(colMapByName.get("ItemSpecification")).getStringCellValue()
							: null;
					String categoryId = row.getCell(colMapByName.get("CategoryId")) != null
							? row.getCell(colMapByName.get("CategoryId")).getStringCellValue()
							: null;
					Double movingAvgPrice = row.getCell(colMapByName.get("MovingAvgPrice")) != null
							? row.getCell(colMapByName.get("MovingAvgPrice")).getNumericCellValue()
							: 0;
					String primaryImage = row.getCell(colMapByName.get("PrimaryImage")) != null
							? row.getCell(colMapByName.get("PrimaryImage")).getStringCellValue()
							: null;

					/*
					 * InventoryDetails inventoryDetails = new InventoryDetails(id, orgLOBCode,
					 * orgLOBName, baseOrgEntityCode, baseOrgEntityName, itemDescription,
					 * itemSpecification, categoryId, movingAvgPrice, primaryImage); Metadata
					 * metadata = new Metadata("update", String.valueOf(id), "4");
					 * inventoryDetails.setMetadata(metadata);
					 */
					JSONObject responseObj = new JSONObject();
					responseObj.put("Id", id);
					responseObj.put("OrgLOBCode", orgLOBCode);
					responseObj.put("OrgLOBName", orgLOBName);
					responseObj.put("BaseOrgEntityCode", baseOrgEntityCode);
					responseObj.put("BaseOrgEntityName", baseOrgEntityName);
					responseObj.put("ItemDescription", itemDescription);
					responseObj.put("CategoryId", categoryId);
					JSONObject metadataObj = new JSONObject();
					metadataObj.put("ActionType", "update");
					metadataObj.put("ObjectCode", String.valueOf(id));
					metadataObj.put("DocumentTypeCode", "4");
					metadataObj.put("ESTypeCode", "4");
					responseObj.put("metadata", metadataObj);
					responseArray.put(responseObj);
				} catch (Exception ex) {
					System.out.println("Failed ID:" + id);
				}

			}

			workbook.close();
			inputStream.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return responseArray.toString();
	}

	@PostMapping(path = "/CreateElasticInventoryData")
	public String CreateElasticInventoryData() throws JsonProcessingException {
		Map<String, JSONObject> orgDetailsMap = new HashMap<String, JSONObject>();
		String orgDetails1 = "{\r\n" + "					\"Organization\": {\r\n"
				+ "						\"EntityDetailCode\": 360,\r\n" + "						\"EntityId\": 1,\r\n"
				+ "						\"EntityKey\": null,\r\n"
				+ "						\"EntityCode\": \"Pertamina\",\r\n" + "						\"Level\": 1,\r\n"
				+ "						\"EntityName\": \"Organization\"\r\n" + "					},\r\n"
				+ "					\"Plant\": {\r\n" + "						\"EntityDetailCode\": 699,\r\n"
				+ "						\"EntityId\": 3,\r\n" + "						\"EntityKey\": null,\r\n"
				+ "						\"EntityCode\": \"R201\",\r\n" + "						\"Level\": 4,\r\n"
				+ "						\"EntityName\": \"Plant\"\r\n" + "					}\r\n" + "				}";
		String orgDetails2 = "{\r\n" + "					\"Plant\": {\r\n"
				+ "						\"EntityName\": \"Plant\",\r\n" + "						\"Level\": 4,\r\n"
				+ "						\"EntityDetailCode\": 362,\r\n"
				+ "						\"EntityKey\": null,\r\n"
				+ "						\"EntityCode\": \"R601\",\r\n" + "						\"EntityId\": 3\r\n"
				+ "					},\r\n" + "					\"Organization\": {\r\n"
				+ "						\"EntityName\": \"Organization\",\r\n"
				+ "						\"Level\": 1,\r\n" + "						\"EntityDetailCode\": 360,\r\n"
				+ "						\"EntityKey\": null,\r\n"
				+ "						\"EntityCode\": \"Pertamina\",\r\n" + "						\"EntityId\": 1\r\n"
				+ "					}\r\n" + "				}";
		JSONObject obj1 = new JSONObject(orgDetails1);
		JSONObject obj2 = new JSONObject(orgDetails2);
		orgDetailsMap.put("R201", obj1);
		orgDetailsMap.put("R601", obj2);
		Map<String, String> slocMap = new HashMap<String, String>();
		slocMap.put("R601", "MGRT");
		slocMap.put("R201", "R6DS");
		JSONArray responseArray = new JSONArray();
		int count = 0;
		for (int i = 500000; i < 1500000; i++) {
			JSONObject responseObj = new JSONObject();
			responseObj.put("Id", i);
			responseObj.put("ItemNumber", "Test " + i);
			responseObj.put("ItemName", "Test Item " + i);
			responseObj.put("ItemDescription", "Test Item " + i);
			responseObj.put("ItemSpecification", "Test Item " + i);
			responseObj.put("ItemType", "MATL");
			responseObj.put("CategoryId", getCategory());
			String plant = getPlant();
			responseObj.put("BaseOrgEntityCode", plant);
			responseObj.put("StorageLocation", slocMap.get(plant));
			responseObj.put("StorageBIN", "SBIN " + i);
			responseObj.put("UOM", "PCS");
			responseObj.put("Ordered", 0);
			responseObj.put("Reserved", 0);
			responseObj.put("Unrestricted", 10);
			responseObj.put("QualityInspection", 0);
			responseObj.put("InTransitStock", 0);
			responseObj.put("MovingAvgPrice", 100.0);
			responseObj.put("OrgLOBCode", "Pertamina");
			responseObj.put("OrgLOBName", "");
			responseObj.put("CreatedBy", "0");
			responseObj.put("ModifiedBy", "0");
			responseObj.put("CreatedOn", "2020-07-01T11:30:55.91");
			responseObj.put("ModifiedOn", "2020-07-01T11:30:55.91");
			responseObj.put("OrgField", orgDetailsMap.get(plant));
			JSONObject metadataObj = new JSONObject();
			metadataObj.put("ActionType", "insert");
			metadataObj.put("ObjectCode", String.valueOf(i));
			metadataObj.put("DocumentTypeCode", "4");
			metadataObj.put("ESTypeCode", "4");
			responseObj.put("metadata", metadataObj);
			responseArray.put(responseObj);
			count++;
			if (count == 10) {
				invokeBulkIngestionAPI(responseArray);
				responseArray = new JSONArray();
				count = 0;
			}
		}

		return "Completed";
	}

	private String getPlant() {
		List<String> plantlist = List.of("R201", "R601");
		Random rand = new Random();
		return plantlist.get(rand.nextInt(plantlist.size()));
	}

	private String getCategory() {
		List<String> categorylist = List.of("7002186250001122", "7002186250001121", "7002186250001123",
				"7002186250001124", "7002186250001128", "7002186250001129", "7002186250001129", "7002186250001135");
		Random rand = new Random();
		return categorylist.get(rand.nextInt(categorylist.size()));
	}

	private void invokeBulkIngestionAPI(JSONArray payload) {
		RestTemplate restTemplate = new RestTemplate();
		String url = "https://api-nexxeqc.gep.com/DMIngestion/api/core/ingest";
		HttpHeaders headers = new HttpHeaders();
		headers.add("Ocp-Apim-Subscription-Key", "89031208dbe043a8b46a883926414e7e");
		headers.add("Authorization",
				"Bearer VdZG9Nd+CMJA6UVBAxPSE5eFdNt3lfJc6CkbmWs1m20NhpAxlaw41lBMHByhfwBlzuwLAdal9wRVZbaQm9+F+k2PW2A60bufj631K1OEcrkVXWzJ5PV2+zyo7PvQWcctN+EenBXY94gjmpLBVIXQrq6pDrKdsNIg3vXq0VuvHvEcBHYilVr6mQw4RKruTUskryaBLBe80h7JA9YPNeojIUPNXqRNzv5Vv27JWfmFww6osK6OWW9xia1wV51gELlVdjjYi1o6U73pw1A0*XpUHa1VKXrXY0wcMyGqGrto9AIofIBHOasN3boHAKwLITJJRSAgdWLDAyCUncnzykmlJgB2VmPXbVAqv4VYIPYTyGfAtqI6+PZNro939iBXI4Z*Q4Dt6VpLFpQBFuB4T0Nmcp7t1z1T9OnrL+LRhjEwE72oFxObnWt6JmHajt8JLpAMUCXSpZ+iWctmPs6yojoz+VCTyZh7n9idvEe9Imq2gVfCrxBHP5NlRFY4*4HmR0p8c+VlISVSqWzgrJSA0xIKsLQL+2+swTc951syuHGpz8OdOUeYcuCJQewWZcCMRrMGsT5DYFAlfoo9RH44TRAbWdB5Crbyj5ztzpDT2YAWsVAhiBmvRgyVsoYrK2G3priivbutVoayw8pGhq9uOIMWGjO3BDA6WUuN9RmvlMgu1f55tOXv0K4BG62KOtm*h5KUMMnNg0lQ7IcwoaVeRzC0KrXoekjjx3Acbf*fdCtCokt40mHnyiPgPiOAFNyU1q*06ik7sRA2maa5Dy84nPbGJ319X3GrKa7pHew5QB0*XzLUZ+EPQt7NPtLf11xb*tM2tJQDcB1nS*g*xRQL*cfzYxCNFEYFpfnaa1LpFIyeD81tKiSOsG7R8waUEngYYh57fl4VVWzxXyAQHKxpg6SNMix++DAV3nfr5d+xHM0ELs8HPSFxvpcsZ6tBZtep11oFjKGI19bN+D9O3ZdlA2NSDDjKLhixVKhzrl*hC6GUHgi0idcSVLImIqWnKuB*7qumTEroXlnH4CNbT12v5ZKaGA==");
		headers.add("GEPSmartTransactionId", "89dd50db-4454-40d3-9969-72d1d9e826cd");
		headers.add("Content-Type", "application/json");
		headers.add("EventType", "DirectMaterials");
		headers.add("SourceSystem", "BillofMaterial");
		HttpEntity<JSONArray> entity = new HttpEntity<JSONArray>(payload, headers);
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
	}
}
