package com.centime.assignment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.centime.assignment.entity.Person;
import com.centime.assignment.service.Implementation.FirstService;

@RestController
public class FirstController {

	@Autowired
	private FirstService service;
	
	@GetMapping("/first")
	public String getHealth() {
		return "Up";

	}

	@PostMapping("/first")
	public String post(@RequestBody Person person) {
		return service.invokeSecondService()+" "+service.invokeThirdService(person);
	}
}
