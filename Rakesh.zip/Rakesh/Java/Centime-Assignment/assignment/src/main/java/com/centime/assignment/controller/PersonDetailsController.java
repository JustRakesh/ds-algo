package com.centime.assignment.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.centime.assignment.service.Implementation.PersonDetailsService;
import com.centime.assignment.view.NestedPersonDetails;
import com.centime.assignment.entity.PersonDetails;

@RestController
public class PersonDetailsController {
	@Autowired
	private PersonDetailsService service;

	@PostMapping(path = "/saveAll")
	public List<PersonDetails> saveAll() {
		List<PersonDetails> personDetails = new ArrayList<PersonDetails>();
		PersonDetails p1 = new PersonDetails(1, 0, "Warrior", "red");
		PersonDetails p2 = new PersonDetails(2, 0, "Wizard", "green");
		PersonDetails p3 = new PersonDetails(3, 0, "Priest", "white");
		PersonDetails p4 = new PersonDetails(4, 0, "Rogue", "yellow");
		PersonDetails p5 = new PersonDetails(5, 1, "Fighter", "blue");
		PersonDetails p6 = new PersonDetails(6, 1, "Paladin", "lighblue");
		PersonDetails p7 = new PersonDetails(7, 1, "Ranger", "lighgreen");
		PersonDetails p8 = new PersonDetails(8, 2, "Mage", "grey");
		PersonDetails p9 = new PersonDetails(9, 2, "Specialist wizard", "lightgrey");
		PersonDetails p10 = new PersonDetails(10, 3, "Cleric", "red");
		PersonDetails p11 = new PersonDetails(11, 3, "Druid", "green");
		PersonDetails p12 = new PersonDetails(12, 3, "Priest of specific mythos", "white");
		PersonDetails p13 = new PersonDetails(13, 4, "Thief", "yellow");
		PersonDetails p14 = new PersonDetails(14, 4, "Bard", "blue");
		PersonDetails p15 = new PersonDetails(15, 13, "Assassin", "lighblue");
		personDetails.add(p1);
		personDetails.add(p2);
		personDetails.add(p3);
		personDetails.add(p4);
		personDetails.add(p5);
		personDetails.add(p6);
		personDetails.add(p7);
		personDetails.add(p8);
		personDetails.add(p9);
		personDetails.add(p10);
		personDetails.add(p11);
		personDetails.add(p12);
		personDetails.add(p13);
		personDetails.add(p14);
		personDetails.add(p15);
		return service.saveAll(personDetails);
	}

	@GetMapping(path = "/findById")
	public PersonDetails findById(@RequestParam long id) {
		return service.findById(id);
	}

	@GetMapping(path = "/findAll")
	public List<NestedPersonDetails> findAll() {
		return null;
	}
}
