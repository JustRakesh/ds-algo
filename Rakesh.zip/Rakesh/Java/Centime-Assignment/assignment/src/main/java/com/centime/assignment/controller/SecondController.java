package com.centime.assignment.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecondController {

	@GetMapping(path = "/second")
	public String get() {
		return "Hello";
	}
}
