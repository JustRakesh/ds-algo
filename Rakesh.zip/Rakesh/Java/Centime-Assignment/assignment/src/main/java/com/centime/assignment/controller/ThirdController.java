package com.centime.assignment.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.centime.assignment.entity.Person;

@RestController
public class ThirdController {

	@PostMapping(path = "/third")
	public String post(@RequestBody Person person) {
		return person.getName() + " " + person.getSurname();
	}
}
