package com.centime.assignment.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InventoryDetails {
	@JsonProperty(value = "Id")
	private long Id;
	@JsonProperty(value = "OrgLOBCode")
	private String OrgLOBCode;
	@JsonProperty(value = "OrgLOBName")
	private String OrgLOBName;
	@JsonProperty(value = "BaseOrgEntityCode")
	private String BaseOrgEntityCode;
	@JsonProperty(value = "BaseOrgEntityName")
	private String BaseOrgEntityName;
	@JsonProperty(value = "ItemDescription")
	private String ItemDescription;
	@JsonProperty(value = "ItemSpecification")
	private String ItemSpecification;
	@JsonProperty(value = "CategoryId")
	private String CategoryId;
	@JsonProperty(value = "MovingAvgPrice")
	private Double MovingAvgPrice;
	@JsonProperty(value = "PrimaryImage")
	private String PrimaryImage;
	private Metadata metadata;

	public InventoryDetails(long id, String orgLOBCode, String orgLOBName, String baseOrgEntityCode,
			String baseOrgEntityName, String itemDescription, String itemSpecification, String categoryId,
			Double movingAvgPrice, String primaryImage) {
		super();
		Id = id;
		OrgLOBCode = orgLOBCode;
		OrgLOBName = orgLOBName;
		BaseOrgEntityCode = baseOrgEntityCode;
		BaseOrgEntityName = baseOrgEntityName;
		ItemDescription = itemDescription;
		ItemSpecification = itemSpecification;
		CategoryId = categoryId;
		MovingAvgPrice = movingAvgPrice;
		PrimaryImage = primaryImage;
	}

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getOrgLOBCode() {
		return OrgLOBCode;
	}

	public void setOrgLOBCode(String orgLOBCode) {
		OrgLOBCode = orgLOBCode;
	}

	public String getOrgLOBName() {
		return OrgLOBName;
	}

	public void setOrgLOBName(String orgLOBName) {
		OrgLOBName = orgLOBName;
	}

	public String getBaseOrgEntityCode() {
		return BaseOrgEntityCode;
	}

	public void setBaseOrgEntityCode(String baseOrgEntityCode) {
		BaseOrgEntityCode = baseOrgEntityCode;
	}

	public String getBaseOrgEntityName() {
		return BaseOrgEntityName;
	}

	public void setBaseOrgEntityName(String baseOrgEntityName) {
		BaseOrgEntityName = baseOrgEntityName;
	}

	public String getItemDescription() {
		return ItemDescription;
	}

	public void setItemDescription(String itemDescription) {
		ItemDescription = itemDescription;
	}

	public String getItemSpecification() {
		return ItemSpecification;
	}

	public void setItemSpecification(String itemSpecification) {
		ItemSpecification = itemSpecification;
	}

	public String getCategoryId() {
		return CategoryId;
	}

	public void setCategoryId(String categoryId) {
		CategoryId = categoryId;
	}

	public Double getMovingAvgPrice() {
		return MovingAvgPrice;
	}

	public void setMovingAvgPrice(Double movingAvgPrice) {
		MovingAvgPrice = movingAvgPrice;
	}

	public String getPrimaryImage() {
		return PrimaryImage;
	}

	public void setPrimaryImage(String primaryImage) {
		PrimaryImage = primaryImage;
	}

	public Metadata getMetadata() {
		return metadata;
	}

	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}

}
