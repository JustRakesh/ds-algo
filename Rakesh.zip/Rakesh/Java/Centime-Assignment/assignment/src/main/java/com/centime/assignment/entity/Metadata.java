package com.centime.assignment.entity;

public class Metadata {

	private String index;
	private String documentCode;
	private String documentTypeCode;

	public Metadata(String index, String documentCode, String documentTypeCode) {
		super();
		this.index = index;
		this.documentCode = documentCode;
		this.documentTypeCode = documentTypeCode;
	}

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	public String getDocumentTypeCode() {
		return documentTypeCode;
	}

	public void setDocumentTypeCode(String documentTypeCode) {
		this.documentTypeCode = documentTypeCode;
	}

}
