package com.centime.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.centime.assignment.entity.PersonDetails;

public interface IPersonDetailsRepository extends JpaRepository<PersonDetails, Long>{

}
