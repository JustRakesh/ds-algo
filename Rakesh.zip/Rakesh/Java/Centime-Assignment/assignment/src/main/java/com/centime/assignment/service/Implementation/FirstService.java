package com.centime.assignment.service.Implementation;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.centime.assignment.entity.Person;
import com.centime.assignment.service.Interface.IFirstService;

@Service
public class FirstService implements IFirstService {
	private String baseUrl = "http://localhost:8080";
	private RestTemplate restTemplate = new RestTemplate();

	@Override
	public String invokeSecondService() {
		String url = baseUrl + "/second";
		return restTemplate.getForObject(url, String.class);
	}

	@Override
	public String invokeThirdService(Person person) {
		String url = baseUrl + "/third";
		return restTemplate.postForObject(url, person, String.class);
	}

}
