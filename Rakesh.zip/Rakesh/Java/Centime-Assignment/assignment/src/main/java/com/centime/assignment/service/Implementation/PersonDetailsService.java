package com.centime.assignment.service.Implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centime.assignment.entity.PersonDetails;
import com.centime.assignment.repository.IPersonDetailsRepository;
import com.centime.assignment.service.Interface.IPersonDetailsService;
import com.centime.assignment.view.NestedPersonDetails;

@Service
public class PersonDetailsService implements IPersonDetailsService {

	@Autowired
	private IPersonDetailsRepository repository;

	@Override
	public List<PersonDetails> saveAll(List<PersonDetails> personDetails) {
		return repository.saveAll(personDetails);
	}

	@Override
	public PersonDetails findById(long id) {
		return repository.findById(id).get();
	}

	@Override
	public List<NestedPersonDetails> findAll() {
		List<PersonDetails> personDetails = repository.findAll();
		List<NestedPersonDetails> nestedPersonDetails = null;
		return null;
	}

}
