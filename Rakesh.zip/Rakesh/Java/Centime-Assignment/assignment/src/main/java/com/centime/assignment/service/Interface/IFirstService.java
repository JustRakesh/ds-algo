package com.centime.assignment.service.Interface;

import com.centime.assignment.entity.Person;

public interface IFirstService {

	public String invokeSecondService();

	public String invokeThirdService(Person person);

}
