package com.centime.assignment.service.Interface;

import java.util.List;
import com.centime.assignment.entity.PersonDetails;
import com.centime.assignment.view.NestedPersonDetails;

public interface IPersonDetailsService {

	public List<PersonDetails> saveAll(List<PersonDetails> personDetails);

	public PersonDetails findById(long id);

	public List<NestedPersonDetails> findAll();
}
