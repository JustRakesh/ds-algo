package com.centime.assignment.view;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NestedPersonDetails {
	@JsonProperty(value = "Name")
	private String name;
	@JsonProperty(value = "Sub Classes")
	private List<SubClasses> subclasses;
}
