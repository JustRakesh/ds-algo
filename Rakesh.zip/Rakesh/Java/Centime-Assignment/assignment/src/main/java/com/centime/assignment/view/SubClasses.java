package com.centime.assignment.view;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SubClasses {
	@JsonProperty(value = "Name")
	private String name;
	@JsonProperty(value = "Sub Classes")
	private List<SubClasses> subclasses;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<SubClasses> getSubclasses() {
		return subclasses;
	}

	public void setSubclasses(List<SubClasses> subclasses) {
		this.subclasses = subclasses;
	}

}
