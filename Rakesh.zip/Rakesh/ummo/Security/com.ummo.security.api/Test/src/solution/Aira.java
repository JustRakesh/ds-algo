package solution;

import java.util.ArrayList;
import java.util.List;

public class Aira {

	/*
	 * Complete the 'getMinimumDifference' function below.
	 *
	 * The function is expected to return an INTEGER_ARRAY. The function accepts
	 * following parameters: 1. STRING_ARRAY a 2. STRING_ARRAY b
	 */

	public static List<Integer> getMinimumDifference(List<String> a, List<String> b) {
		// Write your code here
		List<Integer> result = new ArrayList<Integer>();
		for (int i = 0; i < a.size(); i++) {
			int count = 0;
			String first = a.get(i);
			String second = b.get(i);
			char[] firstArray = first.toCharArray();
			char[] secondArray = second.toCharArray();
			if (firstArray.length == secondArray.length) {
				for (int j = 0; j < firstArray.length; j++) {
					for (int k = 0; k < secondArray.length; k++) {
						if (firstArray[j] == secondArray[k]) {
							break;
						}
						if (k == secondArray.length - 1) {
							count++;
						}
					}

				}
				result.add(count);
			} else {
				result.add(-1);
			}
		}
		return result;
	}

	public static int minSum(List<Integer> num, int k) {
		List<Integer> newList= new ArrayList<Integer>(num);
		for (int i = 0; i < k; i++) {
			int max = newList.stream().mapToInt(value -> value).max().getAsInt();
			int index=newList.indexOf(max);
			double div = (double) max / 2;
			double d = Math.ceil(div);
			newList.remove(index);
			newList.add((int) d);
		}
		return newList.stream().mapToInt(value->value).sum();

	}

	public static void main(String[] args) {
		/*
		 * List<String> first = List.of("a", "jk", "abb", "mn", "abc"); List<String>
		 * second = List.of("bb", "kj", "bbc", "op", "def"); getMinimumDifference(first,
		 * second);
		 */
		List<Integer> input = List.of(10, 20, 7);
		minSum(input, 4);
	}
}
