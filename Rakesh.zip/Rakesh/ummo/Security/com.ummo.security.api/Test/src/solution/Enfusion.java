package solution;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Stack;

public class Enfusion {

	/*
	 * Complete the function below.
	 */
	static void superStack(String[] operations) {
		Stack<Integer> stack = new Stack<Integer>();
		Stack<Integer> auxStack = new Stack<Integer>();
		for (String command : operations) {
			String[] strArray = command.split(" ");
			String cmd = strArray[0];
			if (cmd.equals("push")) {
				stack.push(Integer.valueOf(strArray[1]));
			} else if (cmd.equals("pop")) {
				if (!stack.isEmpty())
					stack.pop();
			} else {
				while (!stack.isEmpty()) {
					auxStack.push(stack.pop());
				}
				while (!auxStack.isEmpty()) {
					for (int i = 0; i < Integer.valueOf(strArray[1]); i++) {
						stack.push(auxStack.pop() + Integer.valueOf(strArray[2]));
					}
					if (!auxStack.isEmpty()) {
						stack.push(auxStack.pop());
					}
				}
			}
			if (!stack.isEmpty())
				System.out.println(stack.peek());
			else {
				System.out.println("EMPTY");
			}
		}

	}

	public static List<String> preprocessDate(List<String> dates)  {
		List<String> response = new ArrayList<String>();
		for (String dateString : dates) {
			dateString = dateString.replaceFirst("[a-zA-Z]{2}", "");
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("d MMMM yyyy");
			Date rightNow=null;
			try {
				rightNow = simpleDateFormat.parse(dateString);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String formattedDate = dateFormat.format(rightNow);
			System.out.println(formattedDate);
		}
		return response;
	}

	public static void main(String[] args) {
		/*
		 * String[] commands = new String[] { "push 15", "pop", "push -51", "pop",
		 * "push 41", "pop", "push -76", "push 51", "push -10", "inc 1 -49" };
		 * superStack(commands);
		 */
		List<String> dates= new ArrayList<String>();
		dates.add("1st Mar 1974");
			preprocessDate(dates);
		
	}
}
