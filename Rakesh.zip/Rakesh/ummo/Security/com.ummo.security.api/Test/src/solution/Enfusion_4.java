package solution;

import java.util.Scanner;

public class Enfusion_4 {

private static final Scanner scan = new Scanner(System.in);
    
    public static void main(String args[]) throws Exception {
        // read the string filename
        String filename;
        filename = scan.nextLine();
        
    }
}
