package solution;

public class Solution {

	
	
	public void findMissingNumbers(int[] input) {
		
		for(int i=0; i< input.length;i++) {
			if(input[i] != i+1) {
				System.out.println(input[i]);
				
			}		
		}	
	}
	1, 2,3,4,1  
	public static void main(String[] args) {
		
	}
}
