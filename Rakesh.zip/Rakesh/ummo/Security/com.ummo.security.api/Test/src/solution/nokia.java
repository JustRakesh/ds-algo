package solution;

public class nokia {
public static void main(String[] args) {
	String [] input = new String[] {"ABC","MNO","XYZ"};
	printReverse(input);
}
	public static void printReverse(String[] input) {
		
		for (int i=0 ;i < input.length; i++) {
			String str=input[i];
			char[] charArray= str.toCharArray();
			for(int j=charArray.length-1 ; j >=0; j--) {
				System.out.print(charArray[j]);
			}
			System.out.println("");
		}
	}
}
