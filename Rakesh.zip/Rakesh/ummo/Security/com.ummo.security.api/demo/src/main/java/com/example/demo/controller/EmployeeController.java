package com.example.demo.controller;


@RestController
public class EmployeeController {

@Autowired
private IEmployeeService service;
	
@RequestMapping("/getEmployeeInSalarayRange")
public List<Employee> getEmployeeInSalarayRange(@RequestParam int min, @RequestParam int max ){
	
	List<Employee> response= service.getEmployeeInSalarayRange(min, max);
	return response;
}
	
}
