package com.example.demo.entity;

import org.hibernate.annotations.Entity;

@Entity
public class Employee {

	@Id
	private int id;
	private String firstName;
	private String lastname;
	private int salary;
	
}
