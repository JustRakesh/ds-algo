package com.example.demo.repository;

public interface IEmployeeRepository extends JPARepository {

	List<Employee> findEmployeeInSalarayRange(int min, int max);
}
