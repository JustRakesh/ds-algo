package com.example.demo.service;

@Service
public class EmployeeService implements IEmployeeService {

	@Autowired
	private IEmployeeRepository repository;
	public List<Employee> getEmployeeInSalarayRange(int min, int max) {
		List<Employee> result =repository.findEmployeeInSalarayRange(min, max);
		return result;
	}
}
