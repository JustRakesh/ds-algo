package com.example.demo.service;

public class IEmployeeService {

	List<Employee> getEmployeeInSalarayRange(int min, int max);
}
